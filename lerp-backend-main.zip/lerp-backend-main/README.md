# lerp-backend [![KITT badge](https://kitt-badges.k8s.walmart.com/kittbadge?org=emergingtechmfg&repo=lerp-backend)](https://concord.prod.walmart.com/#/org/strati/project/pipeline/process?meta.repoMetadata=emergingtechmfg%2Flerp-backend&limit=50) [![Quality Gate Status](https://sonar.looper.prod.walmartlabs.com/api/project_badges/measure?project=mfglerp:lerp-backend&metric=alert_status)](https://sonar.looper.prod.walmartlabs.com/dashboard?id=mfglerp:lerp-backend)

**Description:** This repository contains an example node application using [express framework](https://expressjs.com/es/starter/installing.html) that uses KITT as a continuous delivery pipeline. For a productive artifact update this section and add what this artifact does.

> Requeriments:
>
> - [Node v16.13.0](https://nodejs.org/es/download/releases/)
>
> Recommended:
>
> - [Node Version Manager](https://github.com/nvm-sh/nvm). For Mac users `brew install nvm`
> - [Visual Studio Code](https://code.visualstudio.com/Download).

## How to run locally

If you want to test the accelerator generated locally you must use the following commands:

- `nvm install`
- `npm install`
- `npm run local`
- [Open localhost/health](http://localhost:8080/health)

If everything goes well, you should receive a payload like this:

```bash
HTTP/1.1 200 OK
Content-Security-Policy: default-src 'self';base-uri 'self';block-all-mixed-content;font-src 'self' https: data:;form-action 'self';frame-ancestors 'self';img-src 'self' data:;object-src 'none';script-src 'self';script-src-attr 'none';style-src 'self' https: 'unsafe-inline';upgrade-insecure-requests
Cross-Origin-Embedder-Policy: require-corp
Cross-Origin-Opener-Policy: same-origin
Cross-Origin-Resource-Policy: same-origin
X-DNS-Prefetch-Control: off
Expect-CT: max-age=0
X-Frame-Options: SAMEORIGIN
Strict-Transport-Security: max-age=15552000; includeSubDomains
X-Download-Options: noopen
X-Content-Type-Options: nosniff
Origin-Agent-Cluster: ?1
X-Permitted-Cross-Domain-Policies: none
Referrer-Policy: no-referrer
X-XSS-Protection: 0
Content-Type: text/html; charset=utf-8
Content-Length: 10
ETag: W/"a-stPRrVd0H7w67h0H426SeK7AOKs"
Date: Thu, 24 Feb 2022 12:30:47 GMT
Connection: keep-alive
Keep-Alive: timeout=5
```

`traceId` and `parentId` are generated if not received in headers, according to [W3C rules](https://www.w3.org/TR/trace-context/).

## How to run Jest tests locally

If you want to run the tests with Jest locally you must use the following commands:

- `npm install`
- `npm test` Run integration and unit test
  - `npm run test:unit` Run unit test and coverage
  - `npm run test:integration` Run integration test only

If you want to update the name convention for the integration test you can modify the `package.json` file.

```json
    "test:integration": "jest --testRegex=\\w*.itest.js$"
```

## How to deploy

- Make a commit and push the change
- Check your [Slack Notifications Channel](https://walmart.slack.com/app_redirect?channel=lerp_cloud_deployment) and Visualize the pipeline

**Note:** By default, it is configured for a lab environment, update the Kitt file accordingly to your Project resources if you need a different one.

## Sonar Integration

In order to check out the analysis of your code using the Sonar integration, you will need the following information:

- Sonar Project Key: mfglerp:lerp-backend
- [Sonar Project URL](https://sonar.looper.prod.walmartlabs.com/dashboard?id=mfglerp:lerp-backend)

## Useful Links

- [Looper Project URL](https://ci.wcnp.walmart.com/job/emergingtechmfg/job/lerp-backend/)
- [Splunk](https://wcnp-np-logsearch01.prod.us.walmart.net/en-GB/app/search/search?dispatch.sample_ratio=1&display.page.search.mode=smart&earliest=%40d&kubernetes.container_name=lerp-backend&latest=now&q=search+index%3Dwcnp_mfglerp+kubernetes.container_name%3Dlerp-backend)
- [FAQ](https://confluence.walmart.com/display/CLSKYNET/FAQ)
- [Features included](https://confluence.walmart.com/display/CLSKYNET/Features+Node+Starter+Kit) in this project

## Starter Kit Support

- Contact the [Slack Channel](https://walmart.slack.com/app_redirect?channel=nodejs_starter_kit)
