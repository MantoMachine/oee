const httpContext = require("express-http-context");
const crypto = require("crypto");
const trackingHeaders = require("../../../src/middlewares/traceability");

describe("traceability", () => {
  const res = {};
  const next = jest.fn();
  let expectedTracking, req, mockHttpContext;

  beforeEach(() => {
    mockHttpContext = jest.spyOn(httpContext, "set");
    jest.spyOn(crypto, "randomBytes").mockReturnValue("pikachu");
  });

  afterEach(() => {
    jest.restoreAllMocks();
  });

  test("should set httpContext when traceparent is valid", () => {
    req = {
      headers: {
        traceparent: "00-4bf92f3577b34da6a3ce929d0e0e4736-00f067aa0ba902b7-01",
      },
    };

    expectedTracking = {
      spanId: "pikachu",
      traceId: "4bf92f3577b34da6a3ce929d0e0e4736",
      parentId: "00f067aa0ba902b7",
    };

    trackingHeaders(req, res, next);

    expect(mockHttpContext).toHaveBeenCalledWith("tracking", expectedTracking);
  });

  test("should generate trace headers with the same value that spanId when traceparent is invalid", () => {
    req = {
      headers: {
        traceparent: "00-",
      },
    };

    expectedTracking = {
      spanId: "pikachu",
      traceId: "0000000000000000000000000pikachu",
      parentId: "pikachu",
    };

    trackingHeaders(req, res, next);

    expect(mockHttpContext).toHaveBeenCalledWith("tracking", expectedTracking);
  });

  test("should generate traceId with spanId value when the one received in traceparent is invalid", () => {
    req = {
      headers: {
        traceparent: "00-00000000000000000000000000000000-00f067aa0ba902b7-01",
      },
    };

    expectedTracking = {
      spanId: "pikachu",
      traceId: "0000000000000000000000000pikachu",
      parentId: "00f067aa0ba902b7",
    };

    trackingHeaders(req, res, next);

    expect(mockHttpContext).toHaveBeenCalledWith("tracking", expectedTracking);
  });

  test("should generate parentId with spanId value when the one received in traceparent is invalid", () => {
    req = {
      headers: {
        traceparent: "00-4bf92f3577b34da6a3ce929d0e0e4736-0000000000000000-01",
      },
    };

    expectedTracking = {
      spanId: "pikachu",
      traceId: "4bf92f3577b34da6a3ce929d0e0e4736",
      parentId: "pikachu",
    };

    trackingHeaders(req, res, next);

    expect(mockHttpContext).toHaveBeenCalledWith("tracking", expectedTracking);
  });
});