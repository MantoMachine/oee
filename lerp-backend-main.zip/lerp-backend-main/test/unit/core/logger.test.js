const httpContext = require("express-http-context");
const config = require('config');
const logger = require("../../../src/core/logger");
const stdout = require("test-console").stdout;

describe("logger", () => {
  test("should log with common fields", () => {
    const output = stdout.inspectSync(() => {
      logger.info("message");
    });

    expect(JSON.parse(output[0])).toEqual(
      expect.objectContaining({
        severity: 'info',
        message: 'message',
        projectId: config.get('projectName'),
      })
    );
  });

  test("should log with tracking headers", () => {
    const tracking = {
      spanId: "pikachu",
      traceId: "4bf92f3577b34da6a3ce929d0e0e4736",
      parentId: "00f067aa0ba902b7",
    };

    jest.spyOn(httpContext, "get").mockReturnValueOnce(tracking);

    const output = stdout.inspectSync(() => {
      logger.warn("message");
    });

    expect(JSON.parse(output[0])).toEqual(
      expect.objectContaining({
        severity: 'warn',
        message: 'message',
        projectId: config.get('projectName'),
        spanId: 'pikachu',
        traceId: '4bf92f3577b34da6a3ce929d0e0e4736',
        parentId: '00f067aa0ba902b7',
      })
    );
  });

  test("should log with httpMethod and endpoint", () => {
    jest.spyOn(httpContext, "get").mockReturnValueOnce('');
    jest.spyOn(httpContext, "get").mockReturnValueOnce('httpMethod');
    jest.spyOn(httpContext, "get").mockReturnValueOnce('endpoint');

    const output = stdout.inspectSync(() => {
      logger.warn("message");
    });

    expect(JSON.parse(output[0])).toEqual(
      expect.objectContaining({
        httpMethod: 'httpMethod',
        endpoint: 'endpoint'
      })
    );
  });
});