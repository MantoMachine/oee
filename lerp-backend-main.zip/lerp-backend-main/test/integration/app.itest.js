const app = require("../../src/app");
const supertest = require("supertest");
const request = supertest(app);

describe("Integration test for health endpoint", () => {
  it("Test GET /health with status 200 and message body ", (done) => {
    request.get("/health")
    .expect(200)
    .then(res => {
      expect(res.text).toBe('{"status":"up"}')
      done();
    })
    .catch(err => done(err))
  })

  it("Test GET /liveness with status 200 and message body ", (done) => {
    request.get("/liveness")
    .expect(200)
    .then(res => {
      expect(res.text).toBe("");
      done();
    })
    .catch(err => done(err))
  })
})

