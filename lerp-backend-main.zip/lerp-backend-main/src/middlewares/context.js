const httpContext = require('express-http-context');

const context = (req, res, next) => {
  const { body: requestBody, method, path: url } = req;

  httpContext.set('requestBody', requestBody);
  httpContext.set('method', method);
  httpContext.set('endpoint', url);

  return next();
};

module.exports = context;
