const httpContext = require('express-http-context');
const crypto = require('crypto');

const isInvalidTraceId = (traceId) => traceId.toString() === '00000000000000000000000000000000';

const isInvalidParentId = (parentId) => parentId.toString() === '0000000000000000';

const setDefaultTraceId = (spanId) => spanId.padStart(32, '0');

const setDefaultParentId = (spanId) => spanId;

const parseTrackingHeaders = (traceparent) => {
  const spanId = crypto.randomBytes(8).toString('hex');
  const traceparentFormat = /^[0-9a-fA-F]{2}-[0-9a-fA-F]{32}-[0-9a-fA-F]{16}-[0-9a-fA-F]{2}/;
  let traceId, parentId;

  if (traceparentFormat.test(traceparent)) {
    [, traceId, parentId] = traceparent.split('-');

    traceId = isInvalidTraceId(traceId) ? setDefaultTraceId(spanId) : traceId;
    parentId = isInvalidParentId(parentId) ? setDefaultParentId(spanId) : parentId;
  }

  return {
    spanId,
    traceId: traceId || setDefaultTraceId(spanId),
    parentId: parentId || setDefaultParentId(spanId)
  };
};

const trackingHeaders = (req, res, next) => {
  const { traceparent } = req.headers;

  const { spanId, traceId, parentId } = parseTrackingHeaders(traceparent);

  const tracking = { spanId, traceId, parentId };

  httpContext.set('tracking', tracking);

  return next();
};

module.exports = trackingHeaders;
