const { StatusCodes } = require('http-status-codes');
const stackTraceParser = require('stacktrace-parser');
const logger = require('../core/logger');

const errorHandler = (err, req, res, next) => {
  if (res.headersSent) {
    return next(err);
  }

  const { statusCode, message } = err;

  res.statusCode = StatusCodes[statusCode] ? statusCode : StatusCodes.INTERNAL_SERVER_ERROR;

  res.json({ message });

  logErrors(err, req);

  return next();
};

const getSourceLocation = (err) => {
  const stack = stackTraceParser.parse(err.stack);

  return `${stack[0].file} at line ${stack[0].lineNumber}`;
};

const logErrors = (err, req) => {
  const { body: requestBody } = req;
  const { message: httpMessage, statusCode: httpStatusCode } = err;

  logger.error({
    sourceLocation: getSourceLocation(err),
    httpStatusCode,
    httpMessage,
    requestBody
  });
};

module.exports = errorHandler;
