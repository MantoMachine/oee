const config = require('config');
const httpContext = require('express-http-context');
const { createLogger, format, transports } = require('winston');
const { combine, timestamp, printf } = format;

const customFormat = printf(({ level, message, timestamp }) => {
  const { traceId, parentId, spanId } = httpContext.get('tracking') || {};

  const log = {
    timestamp,
    severity: level,
    projectId: config.get('projectName'),
    httpMethod: httpContext.get('method'),
    endpoint: httpContext.get('endpoint'),
    traceId,
    parentId,
    spanId,
    message
  };

  return JSON.stringify(log);
});

const logger = createLogger({
  format: combine(timestamp(), customFormat),
  transports: [new transports.Console()]
});

module.exports = logger;
