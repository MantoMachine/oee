const express = require("express");
const helmet = require('helmet');
const cors = require('cors');
const httpContext = require("express-http-context");
const trackingHeaders = require("./middlewares/traceability");
const errorHandler = require("./middlewares/error");
const setAppContext = require("./middlewares/context");
const router = require("./routes");
const app = express();

const corsOptions = {
    origin: 'https://*.lider.cl',
}

app.use(helmet());
app.use(express.json());

app.use(cors(corsOptions));
app.use(httpContext.middleware);
app.use(setAppContext);
app.use(trackingHeaders);

app.use("/", router);

app.use(errorHandler);

module.exports = app;
