const http = require('http');
const config = require('config');
const app = require('./app.js');
const logger = require('./core/logger.js');
const port = config.get('port');
const env = config.util.getEnv('NODE_ENV');


const { createTerminus } = require('@godaddy/terminus');

const server = http.createServer(app);

const beforeShutdown = () => {
  logger.info('SIGTERM signal received');
  return new Promise((resolve) => {
    setTimeout(resolve, config.get('readinessTimeFrame'));
  });
};

const onSignal = () => {
  return new Promise(() => {
    server.close(() => {
			logger.info('Server is starting cleanup');
      return Promise.all([
        // your clean logic, like closing database connections
      ]).then(onShutdown);
    });
  });
};

const onShutdown = () => {
  logger.info('Cleanup finished, server is shutting down');
	process.exit(0);
};

const options = {
  timeout: config.get('shutdownTimeout'),
  beforeShutdown,
  onSignal
};

createTerminus(server, options);

server.listen(port, () => logger.info(`Example app listening on port ${port} and using ${env} environment!`));
