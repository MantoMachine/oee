const express = require('express');

const router = express.Router();

router.get('/health', (req, res) => {
  // Health check must validate if the artifact is ready to accept traffic
  res.status(200).json({ status: 'up' });
});

router.get('/liveness', (req, res) => {
  res.status(200).end();
});

module.exports = router;
